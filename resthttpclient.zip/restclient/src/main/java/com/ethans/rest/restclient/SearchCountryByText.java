package com.ethans.rest.restclient;

import org.apache.http.*;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.json.XML;

public class SearchCountryByText {

	public static void main(String[] args) {
		HttpClient httpClient = HttpClientBuilder.create().build();
		try {
			// specify the host, protocol, and port
			//HttpHost target = new HttpHost("https://reqres.in", 80, "http");

			// specify the get request
			HttpGet getRequest = new HttpGet("https://reqres.in/api/users?page=3");

			HttpResponse httpResponse = httpClient.execute(getRequest);
			if (httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
				HttpEntity entity = httpResponse.getEntity();

				System.out.println("----------------------------------------");
				System.out.println(httpResponse.getStatusLine());
				Header[] headers = httpResponse.getAllHeaders();
				for (int i = 0; i < headers.length; i++) {
					System.out.println(headers[i]);
				}
				System.out.println("----------------------------------------");

				if (entity != null) {
					String response = EntityUtils.toString(entity);
					System.out.println(response);

					JSONObject json = new JSONObject(response);
					String xml = XML.toString(json);
					System.out.println("XML out put " + xml);

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}